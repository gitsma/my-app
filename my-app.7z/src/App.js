import React from 'react'
import Products_list from './components/products_list/Products_list';
import Categories from './components/categories/Categories';

const App = () => {
  return (
    <div>
      <Categories/>
      <Products_list/>

    </div>
  )
}

export default App