import React from 'react'
import styles from './Categories.module.css'
import Product_card from '../product/Product_card';
import Products_list from '../products_list/Products_list';


const Categories = (props) => {

    console.log(props.products);
    const newCategory = [...new Set(props.products?.map((value) => value.category))];
    console.log(newCategory);
    
    const filterCategory = (newCategory) => {
    const filteredProducts = props.products?.filter((value => value.category == newCategory));
    console.log(filteredProducts);
    }

  return (
    <div>
        {
            newCategory.map((value, index) => (
                <button  className={styles.CategoryBtn} onClick={()=>filterCategory(value)} key={index}>{value}</button>

            ))
        }

    </div>
  )

}

export default Categories