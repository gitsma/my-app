import React from 'react';
import styles from './Product.module.css';
import Categories from '../categories/Categories';

const Product_card = (props) => {
    console.log(props.products);
    
    
  return (

    <div className={styles.products_list}>
        {
            props.products.map((oneProduct, index) => (
                <div key={index} className = {styles.oneProductCard}>
                    <img className = {styles.productFoto} src ={oneProduct.image}/>
                    <h3 className = {styles.productTitle}>{oneProduct.title}</h3>
                    <h2 className = {styles.productPrice}>{oneProduct.price} € </h2>
                    <button className = {styles.productAddtoCart}>Add to Cart</button>
                </div>
            ))
        }
    </div>
    
  )
}

export default Product_card